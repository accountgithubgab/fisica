document.addEventListener('click', function (e) {

  var self = e.target;

  if (['cel', 'fah', 'kel'].indexOf(self.id) !== -1) {
    var celfah = document.getElementById(self.id === 'cel' ? 'fah' : 'cel');
    var celkel = document.getElementById(self.id === 'cel' ? 'kel' : 'cel');
    var fahkel = document.getElementById(self.id === 'fah' ? 'kel' : 'fah');

    self.removeAttribute('disabled');

    celfah.setAttribute('disabled', '');
    celfah.value = "";
    textPlaceholderNomal();

    celkel.setAttribute('disabled', '');
    celkel.value = "";
    textPlaceholderNomal();

    fahkel.setAttribute('disabled', '');
    fahkel.value = "";
    textPlaceholderNomal();
  }
})

function SomenteNumero(e) {
  var tecla = (window.event) ? event.keyCode : e.which;
  if ((tecla > 47 && tecla < 58)) return true;
  else {
    if (tecla == 8 || tecla == 0) return true;
    else return false;
  }
}

function limpar() {
  document.getElementById('cel').value = null;
  document.getElementById('fah').value = null;
  document.getElementById('kel').value = null;
  document.getElementById('rCel').value = null;
  document.getElementById('rFah').value = null;
  document.getElementById('rKel').value = null;
}

function conversoes() {
  if (document.getElementById('cel').value == "" && document.getElementById('fah').value == "" && document.getElementById('kel').value == "") {
    document.getElementsByName('cel')[0].placeholder = 'Adicionar um valor';
    document.getElementsByName('fah')[0].placeholder = 'Adicionar um valor';
    document.getElementsByName('kel')[0].placeholder = 'Adicionar um valor';

  } else {

    if (document.getElementById('cel').value != "") {
      var C = parseFloat(document.getElementById('cel').value);
      var F;
      var K;

      F = ((C * 9) / 5 + 32).toFixed(2);
      K = ((C + 273.15)).toFixed(2);

      document.getElementById('rCel').value = C + " °C";
      document.getElementById('rFah').value = F + " °F";
      document.getElementById('rKel').value = K + " K";
    }

    if (document.getElementById('fah').value != "") {
      var F = parseFloat(document.getElementById('fah').value);
      var C;
      var K;

      K = ((F - 32) * 5 / 9 + 273).toFixed(2);
      C = ((F - 32) * 5 / 9).toFixed(2);

      document.getElementById('rCel').value = C + " °C";
      document.getElementById('rFah').value = F + " °F";
      document.getElementById('rKel').value = K + " K";
    }

    if (document.getElementById('kel').value != "") {
      var K = parseFloat(document.getElementById('kel').value);
      var C;
      var F;

      C = ((K - 273)).toFixed(2);
      F = ((K - 273) * 9 / 5 + 32).toFixed(2);

      document.getElementById('rCel').value = C + " °C";
      document.getElementById('rFah').value = F + " °F";
      document.getElementById('rKel').value = K + " K";
    }
  }
}

function textPlaceholderNomal() {
  document.getElementsByName('cel')[0].placeholder = 'Temp em Celsius';
  document.getElementsByName('fah')[0].placeholder = 'Temp em Fahrenheit';
  document.getElementsByName('kel')[0].placeholder = 'Temp em Kelvin';
}